"""Test i18n data package."""

from __future__ import annotations
