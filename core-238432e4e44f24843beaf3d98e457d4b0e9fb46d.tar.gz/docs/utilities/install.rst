*****************
Installer scripts
*****************

make\_dist script
=================

.. automodule:: make_dist

setup script
============

.. automodule:: setup

entry point
===========

.. automodule:: pwb
