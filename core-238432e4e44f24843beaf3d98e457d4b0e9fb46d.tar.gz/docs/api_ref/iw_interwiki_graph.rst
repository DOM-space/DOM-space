**********************************************************
:mod:`interwiki\_graph` --- Graphviz Drawing for Interwiki
**********************************************************

.. automodule:: interwiki_graph
   :synopsis: Module with the Graphviz drawing calls
