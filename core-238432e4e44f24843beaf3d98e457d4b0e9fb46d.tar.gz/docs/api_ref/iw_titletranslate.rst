****************************************************
:mod:`titletranslate` --- Interwiki Title Translator
****************************************************

.. automodule:: titletranslate
   :synopsis: Title translate module
