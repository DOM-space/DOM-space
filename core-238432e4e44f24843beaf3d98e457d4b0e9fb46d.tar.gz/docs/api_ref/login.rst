*******************
:mod:`login` module
*******************

.. automodule:: login
   :synopsis: Library to log the bot in to a wiki account
