************************************
:mod:`comms` --- Communication layer
************************************

.. automodule:: comms
   :synopsis: Communication layer


:mod:`comms.eventstreams` --- Server-Sent Events Client
=======================================================

.. automodule:: comms.eventstreams
   :synopsis: Server-Sent Events client

:mod:`comms.http` --- HTTP access interface
===========================================

.. automodule:: comms.http
   :synopsis: Basic HTTP access interface
