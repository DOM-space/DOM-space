*********************************************************
:mod:`cosmetic\_changes` --- Cosmetic Changes of Wikitext
*********************************************************

.. automodule:: cosmetic_changes
   :synopsis: This module can do slight modifications to tidy a wiki page's source code
