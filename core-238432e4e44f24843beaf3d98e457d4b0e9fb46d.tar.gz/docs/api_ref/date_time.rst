******************************************
:mod:`time` --- Time Classes and Functions
******************************************

.. automodule:: pywikibot.time

   .. admonition:: Imports in :mod:`pywikibot` module
      :class: note

      The following class is imported in :mod:`time<pywikibot.time>` module but
      can also be used as :mod:`pywikibot` members:

      - :class:`pywikibot.Timestamp<pywikibot.time.Timestamp>`
