**********************************************************
:mod:`tools.itertools` --- Iterators for Efficient Looping
**********************************************************

.. automodule:: tools.itertools
   :synopsis: Iterator functions
