*******************************************************************
:mod:`tools.formatter` --- Formatting Related Functions and Classes
*******************************************************************

.. automodule:: tools.formatter
   :synopsis: Module containing various formatting related utilities
