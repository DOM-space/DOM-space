***********************************
:mod:`editor` --- Text editor class
***********************************

.. automodule:: editor
   :synopsis: Text editor class for your favourite editor
