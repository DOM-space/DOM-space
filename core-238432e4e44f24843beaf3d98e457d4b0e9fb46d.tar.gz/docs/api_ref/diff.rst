********************************************
:mod:`diff` --- Helpers for computing deltas
********************************************

.. automodule:: diff
   :synopsis: Diff module
