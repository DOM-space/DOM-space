****************************************************
:mod:`echo` --- Echo Extension Classes and functions
****************************************************

.. automodule:: echo
   :synopsis: Classes and functions for working with the Echo extension
