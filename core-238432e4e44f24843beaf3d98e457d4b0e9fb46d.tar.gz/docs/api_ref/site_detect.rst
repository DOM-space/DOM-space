*************************************************************
:mod:`site\_detect` --- Classes for Detecting MediaWiki Sites
*************************************************************

.. automodule:: site_detect
   :synopsis: Classes for detecting a MediaWiki site
