************************************
:mod:`textlib` --- Changing Wikitext
************************************

.. automodule:: textlib
   :synopsis: Functions for manipulating wiki-text
