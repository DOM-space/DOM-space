****************
Template scripts
****************

template script
===============

.. automodule:: scripts.template
   :no-members:
   :noindex:

templatecount script
====================

.. automodule:: scripts.templatecount
   :no-members:
   :noindex:
