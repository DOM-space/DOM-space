*****************************
General pages changes scripts
*****************************

archivebot script
=================

.. automodule:: scripts.archivebot
   :no-members:
   :noindex:

movepages script
================

.. automodule:: scripts.movepages
   :no-members:
   :noindex:

pagefromfile script
===================

.. automodule:: scripts.pagefromfile
   :no-members:
   :noindex:
