****************
Wikibase scripts
****************

claimit script
==============

.. automodule:: scripts.claimit
   :no-members:
   :noindex:

create\_isbn\_edition script
============================

.. automodule:: scripts.create_isbn_edition
   :no-members:
   :noindex:

harvest\_template script
========================

.. automodule:: scripts.harvest_template
   :no-members:
   :noindex:

illustrate\_wikidata script
===========================

.. automodule:: scripts.illustrate_wikidata
   :no-members:
   :noindex:

interwikidata script
====================

.. automodule:: scripts.interwikidata
   :no-members:
   :noindex:

newitem script
==============

.. automodule:: scripts.newitem
   :no-members:
   :noindex:
