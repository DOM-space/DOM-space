****************
Unsorted scripts
****************

basic script
============

.. automodule:: scripts.basic
   :no-members:
   :noindex:

change\_pagelang script
=======================

.. automodule:: scripts.change_pagelang
   :no-members:
   :noindex:

coordinate\_import script
=========================

.. automodule:: scripts.coordinate_import
   :no-members:
   :noindex:

delinker script
===============
.. automodule:: scripts.delinker
   :no-members:
   :noindex:

djvutext script
===============
.. automodule:: scripts.djvutext
   :no-members:
   :noindex:

download\_dump script
=====================

.. automodule:: scripts.download_dump
   :no-members:
   :noindex:

fixing\_redirects script
========================

.. automodule:: scripts.fixing_redirects
   :no-members:
   :noindex:

misspelling script
==================

.. automodule:: scripts.misspelling
   :no-members:
   :noindex:

noreferences script
===================

.. automodule:: scripts.noreferences
   :no-members:
   :noindex:

parser\_function\_count script
==============================

.. automodule:: scripts.parser_function_count
   :no-members:
   :noindex:

reflinks script
===============

.. automodule:: scripts.reflinks
   :no-members:
   :noindex:

replicate\_wiki script
=======================

.. automodule:: scripts.replicate_wiki
   :no-members:
   :noindex:

unlink script
=============

.. automodule:: scripts.unlink
   :no-members:
   :noindex:

watchlist script
================

.. automodule:: scripts.watchlist
   :no-members:
   :noindex:
