********************
tests.aspects module
********************

.. automodule:: tests.aspects
    :members:
    :undoc-members:
    :show-inheritance:
